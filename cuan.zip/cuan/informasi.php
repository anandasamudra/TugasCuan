<div class="row">
	<div class="col-lg-4 col-6">
		<div class="small-box">
			<div class="inner row">
				<div class="col-sm-5"><img class="mb-4" src="dist/img/riska.jpeg" width="100%" style="border-radius: 5px;"></div>
				<div class="col-sm-7">
					<p>Riska Destiana</p>
					<i class="fas fa-university"></i><a href=""> Universitas Janabadra</a><br>
					<i class="far fa-id-badge"></i></i><a href=""> 20330035</a><br>
					<i class="fab fa-whatsapp"></i><a href=""> +62 898-5319-471</a>
				</div>
			</div>
		</div>
	</div>
	<div class="col-lg-4 col-6">
		<div class="small-box">
			<div class="inner row">
				<div class="col-sm-5"><img class="mb-4" src="dist/img/priya.jpeg" width="100%" style="border-radius: 5px;"></div>
				<div class="col-sm-7">
					<p>Priya Mahinnudin</p>
					<i class="fas fa-university"></i><a href=""> Universitas Janabadra</a><br>
					<i class="far fa-id-badge"></i></i><a href=""> 20330018</a><br>
					<i class="fab fa-whatsapp"></i><a href=""> +62 888-2664-031</a>
				</div>
			</div>
		</div>
	</div>
	<div class="col-lg-4 col-6">
		<div class="small-box">
			<div class="inner row">
				<div class="col-sm-5"><img class="mb-4" src="dist/img/nanda.jpeg" width="100%" style="border-radius: 5px;"></div>
				<div class="col-sm-7">
					<p>Ananda Bagus Lanang Samudra</p>
					<i class="fas fa-university"></i><a href=""> Universitas Janabadra</a><br>
					<i class="far fa-id-badge"></i></i><a href=""> 20330040</a><br>
					<i class="fab fa-whatsapp"></i><a href=""> +62 857-0074-6138</a>
				</div>
			</div>
		</div>
	</div>
	<div class="col-lg-12">
		<div class="small-box ">
			<div class="inner">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3953.054853924092!2d110.3551965145087!3d-7.784009179394606!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a583d1d2303bb%3A0x3f6cb15eeaa2fe2f!2sUniversitas%20Janabadra!5e0!3m2!1sid!2sid!4v1639667239150!5m2!1sid!2sid" width="100%" height="310" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
			</div>
		</div>
	</div>

