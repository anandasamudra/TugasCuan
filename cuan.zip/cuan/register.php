<?php
  include "inc/koneksi.php";
   
?>

<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Cuanku | Buat Akun</title>
	<link rel="icon" href="dist/img/C.png">
	<!-- Tell the browser to be responsive to screen width -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Font Awesome -->
	<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
	<!-- Ionicons -->
	<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
	<!-- icheck bootstrap -->
	<link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
	<!-- Theme style -->
	<link rel="stylesheet" href="dist/css/adminlte.min.css">
	<!-- Google Font: Source Sans Pro -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

</head>
<body class="hold-transition login-page" style="background-image: url('dist/img/bacg.jpg'); background-size: cover;">
	<div class="login-box">
		<div class="card">
			<div class="card-body login-card-body text-center">
				<img class="mb-4" src="dist/img/Cuanku.png" alt=""  width="120">
				<h5>Form Buat Akun</h5><br>
				<form action="" method="post">
                    <div class="input-group mb-3">
						<input type="text" class="form-control" name="nama_pengguna" placeholder="Nama" required>
					</div>
					<div class="input-group mb-3">
						<input type="text" class="form-control" name="username" placeholder="Username" required>
					</div>
                    <div class="input-group mb-3">
						<input type="password" class="form-control" name="password" placeholder="Password" required>
					</div>
					<div class="row">
						<div class="col-6">
							<button href="login.php" type="reset" class="btn btn-outline-primary btn-block btn-flat">
								<b>Batal</b>
							</button>
						</div>
						<div class="col-6 row">
							<button type="submit" class="btn btn-primary btn-block btn-flat" name="btnregister" title="Masuk Sistem">
								<b>Daftar</b>
							</button>
						</div>
						<div class="col-12"><br>
							<a href="login.php">Masuk Akun</a>
						</div>
					</div>
				</form>

				</div>
			</div>
		</div>
		<!-- /.login-box -->

		<!-- jQuery -->
		<script src="plugins/jquery/jquery.min.js"></script>
		<!-- Bootstrap 4 -->
		<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
		<!-- AdminLTE App -->
		<script src="dist/js/adminlte.min.js"></script>
		<!-- Alert -->
		<script src="plugins/alert.js"></script>

</body>

</html>

<?php

if (isset($_POST['btnregister'])) {
	$nama_pengguna=$_POST['nama_pengguna'];
	$username=$_POST['username'];
	$password=$_POST['password'];

	$query_inputan="INSERT INTO tb_pengguna VALUES (NULL,'$nama_pengguna','$username','$password','User')";
	$hasil = mysqli_query($koneksi,$query_inputan);

	if ($hasil){
		echo "<script>
			Swal.fire({title: 'Buat Akun Berhasil Silahkan Log in',text: '',icon: 'success',confirmButtonText: 'OK'
			}).then((result) => {if (result.value)
				{window.location = 'http://localhost/cuan/register';}
			})</script>";
		}else{
		echo "<script>
			Swal.fire({title: 'Buat Akun Gagal',text: '',icon: 'error',confirmButtonText: 'OK'
			}).then((result) => {if (result.value)
				{window.location = 'register';}
			})</script>";
		}
	}