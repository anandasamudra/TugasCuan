-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 23 Des 2021 pada 14.28
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cuanku`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kas_pribadi`
--

CREATE TABLE `kas_pribadi` (
  `id_km` int(11) NOT NULL,
  `tgl_km` date NOT NULL,
  `uraian_km` varchar(200) NOT NULL,
  `masuk` int(11) NOT NULL,
  `keluar` int(11) NOT NULL,
  `jenis` enum('Masuk','Keluar') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kas_pribadi`
--

INSERT INTO `kas_pribadi` (`id_km`, `tgl_km`, `uraian_km`, `masuk`, `keluar`, `jenis`) VALUES
(2, '2020-03-20', 'Kotak Amal Bulan Maret 3', 200000, 0, 'Masuk'),
(3, '2020-03-24', 'Amal hamba Alloh', 100000, 0, 'Masuk'),
(6, '2020-03-03', 'Bisaroh Gus Nasih', 0, 80000, 'Keluar'),
(7, '2020-03-01', 'tes js', 200000, 0, 'Masuk'),
(8, '2020-03-03', 'tes 2 js', 10000, 0, 'Masuk'),
(9, '2020-03-30', 'regek', 70000, 0, 'Masuk'),
(10, '2020-03-30', 'iso regek', 100000, 0, 'Masuk'),
(11, '2020-03-30', 'cara yusuf', 50000, 0, 'Masuk'),
(13, '2020-03-02', 'rg keluar', 0, 25000, 'Keluar'),
(14, '2020-03-01', 'plk', 2000000, 0, 'Masuk'),
(15, '2020-03-31', 'beli kuda', 1000002, 0, 'Masuk'),
(17, '2020-05-19', 'contoh', 0, 750000, 'Keluar');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kas_sesama`
--

CREATE TABLE `kas_sesama` (
  `id_ks` int(11) NOT NULL,
  `tgl_ks` date NOT NULL,
  `uraian_ks` varchar(200) NOT NULL,
  `masuk` int(11) NOT NULL,
  `keluar` int(11) NOT NULL,
  `jenis` enum('Masuk','Keluar') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kas_sesama`
--

INSERT INTO `kas_sesama` (`id_ks`, `tgl_ks`, `uraian_ks`, `masuk`, `keluar`, `jenis`) VALUES
(3, '2020-03-24', 'bantu banjir', 0, 150000, 'Keluar'),
(5, '2020-03-20', 'Hamba Alloh', 1000000, 0, 'Masuk'),
(6, '2020-03-01', 'tes tanpa internet', 200000, 0, 'Masuk'),
(7, '2020-03-27', 'tes 123', 0, 10000, 'Keluar'),
(8, '2020-03-23', 'regek sos', 120000, 0, 'Masuk'),
(9, '2020-03-02', 'metu rg', 0, 15000, 'Keluar'),
(10, '2020-03-15', 'tes lg', 230000, 0, 'Masuk');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pengguna`
--

CREATE TABLE `tb_pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `nama_pengguna` char(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `level` enum('Administrator','User') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pengguna`
--

INSERT INTO `tb_pengguna` (`id_pengguna`, `nama_pengguna`, `username`, `password`, `level`) VALUES
(2, 'Admin', 'admin', 'admin123', 'Administrator'),
(8, 'Momoooo', 'user', 'user123', 'User'),
(19, 'ananda', 'ananda', 'ananda123', 'User');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `kas_pribadi`
--
ALTER TABLE `kas_pribadi`
  ADD PRIMARY KEY (`id_km`);

--
-- Indeks untuk tabel `kas_sesama`
--
ALTER TABLE `kas_sesama`
  ADD PRIMARY KEY (`id_ks`);

--
-- Indeks untuk tabel `tb_pengguna`
--
ALTER TABLE `tb_pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `kas_pribadi`
--
ALTER TABLE `kas_pribadi`
  MODIFY `id_km` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `kas_sesama`
--
ALTER TABLE `kas_sesama`
  MODIFY `id_ks` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `tb_pengguna`
--
ALTER TABLE `tb_pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
